{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "hkube.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "hkube.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "hkube.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Whether HKube should create its RBAC objects. Returns "true" or "" (empty = false).
Defaults to true when global.rbac.create is absent (e.g. upgrade --reuse-values from an older release).
*/}}
{{- define "hkube.rbac.create" -}}
{{- $rbac := ((.Values.global).rbac) | default dict -}}
{{- if or (not (hasKey $rbac "create")) (ne (toString $rbac.create) "false") -}}true{{- end -}}
{{- end -}}


{{/*
Return the target Kubernetes version
*/}}
{{- define "common.capabilities.kubeVersion" -}}
{{- if .Values.global }}
    {{- if .Values.global.kubeVersion }}
    {{- .Values.global.kubeVersion -}}
    {{- else }}
    {{- default .Capabilities.KubeVersion.Version .Values.kubeVersion -}}
    {{- end -}}
{{- else }}
{{- default .Capabilities.KubeVersion.Version .Values.kubeVersion -}}
{{- end -}}
{{- end -}}

{{/*
Return the appropriate apiVersion for cronjob.
*/}}
{{- define "cronjob.apiVersion" -}}
{{- if .Values.cronjob -}}
{{- if .Values.cronjob.apiVersion -}}
{{- .Values.cronjob.apiVersion -}}
{{- else if semverCompare "<1.21-0" (include "common.capabilities.kubeVersion" .) -}}
{{- print "batch/v1beta1" -}}
{{- else -}}
{{- print "batch/v1" -}}
{{- end }}
{{- else if semverCompare "<1.21-0" (include "common.capabilities.kubeVersion" .) -}}
{{- print "batch/v1beta1" -}}
{{- else -}}
{{- print "batch/v1" -}}
{{- end -}}
{{- end -}}

{{/*
Return the appropriate apiVersion for ingress.
*/}}
{{- define "ingress.apiVersion" -}}
{{- if .Values.ingress -}}
{{- if .Values.ingress.apiVersion -}}
{{- .Values.ingress.apiVersion -}}
{{- else if semverCompare "<1.21-0" (include "common.capabilities.kubeVersion" .) -}}
{{- print "extensions/v1beta1" -}}
{{- else -}}
{{- print "networking.k8s.io/v1" -}}
{{- end }}
{{- else if semverCompare "<1.21-0" (include "common.capabilities.kubeVersion" .) -}}
{{- print "extensions/v1beta1" -}}
{{- else -}}
{{- print "networking.k8s.io/v1" -}}
{{- end -}}
{{- end -}}

{{/*
Generate backend entry that is compatible with all Kubernetes API versions.
Usage:
{{ include "common.ingress.backend" (dict "serviceName" "backendName" "servicePort" "backendPort" "context" $) }}

Params:
  - serviceName - String. Name of an existing service backend
  - servicePort - String/Int. Port name (or number) of the service. It will be translated to different yaml depending if it is a string or an integer.
  - context - Dict - Required. The context for the template evaluation.
*/}}
{{- define "ingress.backend" -}}
{{- $apiVersion := (include "ingress.apiVersion" .context) -}}
{{- if or (eq $apiVersion "extensions/v1beta1") (eq $apiVersion "networking.k8s.io/v1beta1") -}}
serviceName: {{ .serviceName }}
servicePort: {{ .servicePort }}
{{- else -}}
service:
  name: {{ .serviceName }}
  port:
    {{- if typeIs "string" .servicePort }}
    name: {{ .servicePort }}
    {{- else if or (typeIs "int" .servicePort) (typeIs "float64" .servicePort) }}
    number: {{ .servicePort | int }}
    {{- end }}
{{- end -}}
{{- end -}}

{{/*
Print "true" if the API pathType field is supported
Usage:
{{ include "common.ingress.supportsPathType" . }}
*/}}
{{- define "ingress.supportsPathType" -}}
{{- if (semverCompare "<1.18-0" (include "common.capabilities.kubeVersion" .)) -}}
{{- print "false" -}}
{{- else -}}
{{- print "true" -}}
{{- end -}}
{{- end -}}

{{/*
Return the apiVersion for Traefik CRDs (Middleware).
*/}}
{{- define "ingress.traefik.apiVersion" -}}
{{- .Values.global.ingress.traefik.apiVersion | default "traefik.io/v1alpha1" -}}
{{- end -}}

{{/*
Render traefik router annotations: entrypoints and middleware chain.
Prepends the shared redirect-to-https middleware when global.ingress.requireTls is set.
Usage:
{{ include "ingress.traefik.annotations" (dict "middlewares" (list "gc-service-strip-prefix") "context" $) }}
*/}}
{{- define "ingress.traefik.annotations" -}}
{{- $ns := .context.Release.Namespace -}}
{{- $names := .middlewares | default list -}}
{{- if .context.Values.global.ingress.requireTls }}
{{- $names = prepend $names "redirect-to-https" }}
{{- end }}
{{- $refs := list -}}
{{- range $names }}
{{- $refs = append $refs (printf "%s-%s@kubernetescrd" $ns .) }}
{{- end }}
{{- with .context.Values.global.ingress.traefik.entrypoints }}
traefik.ingress.kubernetes.io/router.entrypoints: {{ . | quote }}
{{- end }}
{{- if $refs }}
traefik.ingress.kubernetes.io/router.middlewares: {{ join "," $refs | quote }}
{{- end }}
{{- end -}}

{{/*
Render a traefik stripPrefix Middleware (replacement for nginx rewrite-target: /$2).
Usage:
{{ include "ingress.traefik.stripPrefixMiddleware" (dict "name" "gc-service" "prefixes" (list "/hkube/gc-service") "context" $) }}
*/}}
{{- define "ingress.traefik.stripPrefixMiddleware" -}}
apiVersion: {{ include "ingress.traefik.apiVersion" .context }}
kind: Middleware
metadata:
  name: {{ .name }}-strip-prefix
  labels:
    app: {{ .app | default .name }}
    release: {{ .context.Release.Name }}
    heritage: {{ .context.Release.Service }}
    group: {{ .context.Values.labels.group.value }}
    core: "true"
spec:
  stripPrefix:
    prefixes:
    {{- range .prefixes }}
    - {{ . | quote }}
    {{- end }}
{{- end -}}


{{/*
Returns a Json-formatted dictionary containing "thirdParty" and "services" to replace according
to the $.Values.metrics.grafana_version ( currently supports 6/7)
Usage:
{{ include "grafanaVersionUtility" . | fromJson }}
*/}}
{{- define "grafanaVersionUtility" -}}
  {{- $placeHolderDict := dict }}
  {{- $_ := set $placeHolderDict "grafanaDataSource" (toString $.Values.metrics.grafana_data_source) -}}
  {{ $placeHolderDict | toJson}}
{{- end -}}